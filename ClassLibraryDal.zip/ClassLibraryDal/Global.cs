﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDal
{
        public static class GlobalVar
        {
            public static string? custemail { get; set; }
            public static string? labemail { get; set; }
            public static string? Semail { get; set; }
            public static int LabourerId { get; set; }
            public static string? comment { get; set; } = null;
            public static int reviews { get; set; }
            public static string? FName { get; set; }
            public static string? LName { get; set; }
            public static string? Skill { get; set; }
            public static string? Experience { get; set; }
            public static string? Price { get; set; }


    }

}
